# Debug section

Here are pieces of code used by developper to debug cxsom (when needed....)

