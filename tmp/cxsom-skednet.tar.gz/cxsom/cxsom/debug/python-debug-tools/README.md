# Python debugging tools

When cxsom processor is used in some debug modes (for developpers), it can generate debugging data. Here are some tools for visualization of such data.

Users can ignore this.

