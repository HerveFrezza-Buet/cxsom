#include <cxsomVariable.hpp>

/**
 * @example example-001-001-datafile.cpp
 */
