
import setuptools

setuptools.setup(
    name = "pysked",
    version = "1.0",
<<<<<<< HEAD
    scripts = ['bin/pysked-timeline-to-pdf.py'],
    #packages = setuptools.find_packages(),
=======
    scripts = ['bin/pysked-timeline-to-pdf.py']
>>>>>>> main
)
