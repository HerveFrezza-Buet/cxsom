# sked

Sked enable to synchronize multi-thread access to simulation stages.

## Install

### C++ libraries

In this directory:

```
mkdir build
cd build
cmake .. -DCMAKE_INSTALL_PREFIX=/usr
make
sudo make install
cd ..
```

### Python libraries

In this directory:

```
cd pysked/
python3 setup.py install --user
cd ..
```



