# This provide tools for building up cxsom-based designs.

## Installation


Go into the `cxsom-builder` directory you have git-cloned. Then type

```mkdir build
cd build
cmake .. -DCMAKE_INSTALL_PREFIX=/usr
make -j
sudo make install
```

## Examples and experiments

There are examples in the documentation in order to illustrate the use of cxsom-builder. Experiments are available in the experiment section.

