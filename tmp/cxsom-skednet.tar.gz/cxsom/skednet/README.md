# skednet

This enable to use sked between processes running on distinct machines.


## Install

In this directory:

```
mkdir build
cd build
cmake .. -DCMAKE_INSTALL_PREFIX=/usr
make
sudo make install
cd ..
```